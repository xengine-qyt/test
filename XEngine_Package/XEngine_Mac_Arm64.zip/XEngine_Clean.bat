@echo Off
del /s /a /q "*.h"
del /s /a /q "*.types"

del /s /a /q "*.a"
del /s /a /q "*.so"
del /s /a /q "*.dylib"
del /s /a /q "*.lib"
del /s /a /q "*.dll"
del /s /a /q "*.exe"

del ".\XEngine_Linux\xengine"
del ".\XEngine_Android\xengine"
del ".\XEngine_IOS\xengine"
del ".\XEngine_Mac\xengine"